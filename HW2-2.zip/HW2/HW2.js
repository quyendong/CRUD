/*
Quyen Dong
W899090
CSC440
HW2
Assignment:
We dealt with the bag class in CSC 307. 
Write the bag class in JavaScript to store strings where the data is stored is a JavaScript array. 
You should provide methods to 
	insert a new item, 
	remove an existing item and 
	search for an item as well as 
	replace an item with a new item. 
There are the so-called CRUD (Create, Read, Update and Delete) operations that lots of websites talk about.
*/

console.log("This program has the ability to insert, remove, search, or replace an item.")
let string = ["HelloMoto!", "YankeeDoodle", "PurpleRain", "Computer"];

console.log("Here are the following strings:");
for (i=0; i<string.length; i++)
	{
		console.log(i+1, ": ", string[i]);
	}

iString = "HelloThere";
insert(iString);
dString = string[2];
remove(dString);
sString = string[1];
search(sString);
rString = string[0];
nString = "Orange Cupcakes"
replace(rString, nString) 
 
function insert(path)
{
	console.log("I will insert the string: ", path);
	string.push(path);
	for (i=0; i<string.length; i++)
	{
		console.log(i+1, ": ", string[i]);
	}	
}
		
function remove(path)
{
	console.log("I will remove string: ", path);
	index = string.indexOf(path);
	string.splice(index, 1)
	for (i=0; i<string.length; i++)
	{
		console.log(i+1, ": ", string[i]);
	}	
}

function search(path)
{
	console.log("I will search for string: ", path);
	for (i = 0; i < string.length; i++)
	{
		if (path == string[i]) 
		{
			console.log("There is a match.");
			console.log("Index: ", i+1);
			return i;
		}
	}
}
			
function replace(path, newpath)
{
	console.log("I will replace string: ", path, " with ", newpath);
	for (i = 0; i < string.length; i++)
	{
		if (path == string[i]) 
		{
			index = i;
		}
	}
	string[index] = newpath;
	for (i=0; i<string.length; i++)
	{
		console.log(i+1, ": ", string[i]);
	}
}

